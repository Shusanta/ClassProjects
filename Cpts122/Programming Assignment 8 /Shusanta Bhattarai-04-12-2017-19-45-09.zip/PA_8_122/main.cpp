#include "DataAnalysis.h"

//Shusanta Bhattarai

int main(void)
{
	DataAnalysis data; //instantiates an object

	data.run_Analysis(); //does all functions


}