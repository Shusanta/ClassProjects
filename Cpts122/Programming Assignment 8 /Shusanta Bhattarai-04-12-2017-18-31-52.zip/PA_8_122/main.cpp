#include "DataAnalysis.h"

int main(void)
{
	DataAnalysis data;

	data.run_Analysis();

}