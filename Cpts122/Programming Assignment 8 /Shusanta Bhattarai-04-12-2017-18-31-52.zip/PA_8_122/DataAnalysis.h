#pragma once
#include "BST.h"
#include <fstream>

class DataAnalysis
{
public:
	DataAnalysis() {}
	~DataAnalysis();
	void run_Analysis();
	void return_data();

private:
	BST mTreeSold;
	BST mTreePurchased;
	std::ifstream mCSVstream;
	void open_File_Stream();
	void parse();

};

void DataAnalysis::run_Analysis()
{
	open_File_Stream();

	parse();

	return_data();
}

inline void DataAnalysis::open_File_Stream()
{
	mCSVstream.open("data.txt");
}

inline void DataAnalysis::parse()
{
	std::string temp_Units;
	std::string temp_Type;
	std::string order;
	getline(mCSVstream, temp_Units);

	while (getline(mCSVstream, temp_Units, ','))
	{
		getline(mCSVstream, temp_Type, ',');

		getline(mCSVstream, order);

		if (order == "Purchased")
		{
			mTreePurchased.insert(temp_Type, stoi(temp_Units));
		}
		else
		{
			mTreeSold.insert(temp_Type, stoi(temp_Units));
		}
		
	}
}

inline DataAnalysis::~DataAnalysis()
{
	mCSVstream.close();
}

inline void DataAnalysis::return_data()
{
	TransactionNode mostPurchased = mTreePurchased.find_Largest();
	TransactionNode mostSold = mTreeSold.find_Largest();
	TransactionNode leastPurchased = mTreePurchased.find_Smallest();
	TransactionNode leastSold = mTreeSold.find_Smallest();

	std::cout << "most Purchased " << mostPurchased.get_Data() << " " << mostPurchased.getUnits() << "\n";
	std::cout << "most Sold" << mostSold.get_Data() << " " << mostSold.getUnits() << "\n";
	std::cout << "least Purchased " << leastPurchased.get_Data() << " " << leastPurchased.getUnits() << "\n";
	std::cout << "least Sold" << leastSold.get_Data() << " " << leastSold.getUnits() << "\n";


}