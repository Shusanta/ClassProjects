#include "menu.h"
int main(void)
{
	menu a;

	a.opt();
}