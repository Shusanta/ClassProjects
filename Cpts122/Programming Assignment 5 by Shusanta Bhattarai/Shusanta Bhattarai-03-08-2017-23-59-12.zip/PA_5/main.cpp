#include "fitappwrapper.h"

//collaborated with edgar perez
int main(void)
{
	fitappwrapper wrapper;

	wrapper.runapp();
}